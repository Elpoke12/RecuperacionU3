﻿using System;
using System.Collections;

namespace Ejercicio_namber3
{
    class Capitalismo
    {
        public void Iniciar()
        {
            //Iniciamos el metodo Stack
            Stack Valor = new Stack(); 
            Valor.Push(2);
            Valor.Push(3);
            Valor.Push(6);
            Valor.Push(4);
            Valor.Push(7);
            Valor.Push("j");
            Valor.Push(2);
            Valor.Push(0.1);
            Valor.Push("Tec");
            Valor.Push(23);
            Valor.Push(65);
            //Se guardan los elementos
            foreach (var item in Valor)
            {
                //Se despliega los valores
                Console.WriteLine("->{0}", item);  
            }
            /*Al momento de imprimir los valores del stack el primer numero de la lista para ser el ultimo y
             * el ultimo pasara siendo el primero siguendo la secuencia con los demas forech */

            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());//Pop es el que esta elimiando el primer valor 
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);//Aqui se va a desplegar sin datos removidos
            }
            Console.WriteLine("");
            //Aqui se estara removiendo el primero valor de la lista
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);//Aqui se va a desplegar sin datos removidos
            }
            Console.WriteLine("");
            //Aqui se estara removiendo el primero valor de la lista
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.WriteLine(Valor.Pop());
            foreach (var item in Valor)
            {
                Console.WriteLine("->{0}", item);
            }
            Console.WriteLine("");
            Console.ReadKey();
        }
    

        static void Main(string[] args)
        {
            Capitalismo ggmen = new Capitalismo();
            ggmen.Iniciar();
            Console.ReadKey();
        }
    }

}

