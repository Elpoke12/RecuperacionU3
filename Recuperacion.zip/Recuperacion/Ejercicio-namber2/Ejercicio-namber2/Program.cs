﻿using System;
using System.Collections;

namespace Ejercicio_namber2
{
    class Socialismo
    {
        public void Queue()
        {
            Console.WriteLine("Que valores retornara durante la siguiente secuencia de operaciones de cola, si se ejecuta sobre una cola inicialmente vacia");
            //Se crea la cola huehue
            Queue Numero = new Queue();

            Numero.Enqueue(5);
            Numero.Enqueue(3);
            //Guarda los valores de la cola en la variable
            foreach (var item in Numero)
            {
                //Imprime el resultado
                Console.WriteLine("Valor: {0}", item);
            }
            //Elimina el numero que ahora queda como primero y asi sucesivamente en los demas forech hace lo mismo en cada cola
            Console.WriteLine(Numero.Dequeue());
            // Guarda la cola en la variable despues de remover
            foreach (var item in Numero)
            {
                //Imprime el resultado despues de remover el primero
                Console.WriteLine("Valor: {0}", item);
            }
            Numero.Enqueue(2);
            Numero.Enqueue(8);
            //Elimina el numero que ahora queda como primero y asi sucesivamente en los demas forech hace lo mismo en cada cola
            Console.WriteLine(Numero.Dequeue());
            // Guarda la cola en la variable despues de remover
            foreach (var item in Numero)
            {
                //Imprime el resultado despues de remover el primero
                Console.WriteLine("Valor: {0}", item);
            }
            Numero.Enqueue(9);
            Numero.Enqueue(1);
            //Elimina el numero que ahora queda como primero y asi sucesivamente en los demas forech hace lo mismo en cada cola
            Console.WriteLine(Numero.Dequeue());
            // Guarda la cola en la variable despues de remover
            foreach (var item in Numero)
            {
                //Imprime el resultado despues de remover el primero
                Console.WriteLine("Valor: {0}", item);
            }
            Numero.Enqueue(7);
            Numero.Enqueue(6);
            //Elimina el numero que ahora queda como primero y asi sucesivamente en los demas forech hace lo mismo en cada cola
            Console.WriteLine(Numero.Dequeue());
            // Guarda la cola en la variable despues de remover
            foreach (var item in Numero)
            {
                //Imprime el resultado despues de remover el primero
                Console.WriteLine("Valor: {0}", item);
            }
            //Elimina el numero que ahora queda como primero y asi sucesivamente en los demas forech hace lo mismo en cada cola
            Console.WriteLine(Numero.Dequeue());
            // Guarda la cola en la variable despues de remover
            foreach (var item in Numero)
            {
                //Imprime el resultado despues de remover el primero
                Console.WriteLine("Valor: {0}", item);
            }
            Numero.Enqueue(4);
            //Elimina el numero que ahora queda como primero y asi sucesivamente en los demas forech hace lo mismo en cada cola
            Console.WriteLine(Numero.Dequeue());
            // Guarda la cola en la variable despues de remover
            foreach (var item in Numero)
            {
                //Imprime el resultado despues de remover el primero
                Console.WriteLine("Valor: {0}", item);
            }
            //Elimina el numero que ahora queda como primero y asi sucesivamente en los demas forech hace lo mismo en cada cola
            Console.WriteLine(Numero.Dequeue());
            // Guarda la cola en la variable despues de remover
            foreach (var item in Numero)
            {
                //Imprime el resultado despues de remover el primero
                Console.WriteLine("Valor: {0}", item);
            }
            Console.ReadKey();

        }
        static void Main(string[] args)
        {
            Socialismo ggmen = new Socialismo();
            ggmen.Queue();
        }
    }
}
