﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace Ejercicio_namber1
{
    class ListaArrayList1
    {
        public void Lista()
        {
            //Creacion de la lista
            ArrayList Valor = new ArrayList();
            //Aqui se esta creando la lista donde se van a copiar los datos
            ArrayList CopyCat = new ArrayList();
                                              
            Valor.Add("Elemento #1: 2");
            Valor.Add("Elemento #2: 3");
            Valor.Add("Elemento #3: 4");
            Valor.Add("Elemento #4: 7.5");
            Valor.Add("Elemento #5: 4");
            Valor.Add("Elemento #6: H");
            Valor.Add("Elemento #7: U");
            Valor.Add("Elemento #8: J");
            Valor.Add("Elemento #9: 67");
            Valor.Add("Elemento #10: 23");
            Valor.Add("Elemento #12: 9");
            Valor.Add("Elemento #13: 80");

            Console.WriteLine("La Lista original es: ");
            //Aqui esta recorriendo la lista para obtener los valores
            foreach (var item in Valor) 
                //Despliega la lista
                Console.WriteLine(item);
            Console.WriteLine("/////////////////////////////////");
            Console.WriteLine("La lista clonada es: ");
            //En esta parte ya que se leyeron los datos de la lista pasada, ahora con el forech los vuelve a recorrer
            CopyCat = (ArrayList)Valor.Clone();
            foreach (var item in Valor)
                //Despliega la lista
                Console.WriteLine(item);

            Console.ReadKey();
        }
    
    static void Main(string[] args)
    {
            ListaArrayList1 ggmen = new ListaArrayList1();
            ggmen.Lista();
        }
    }
}

